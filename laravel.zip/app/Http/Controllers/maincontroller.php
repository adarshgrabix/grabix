<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;

class maincontroller extends Controller
{
   public function index()
   {
       $ads = \DB::select('select * from data where id=1');
	   $slide1 = \DB::select('select * from slider where id=1');
	   $slide2 = \DB::select('select * from slider where id=2');
	   $slide3 = \DB::select('select * from slider where id=3');
	    $promodata = \DB::select('select * from promobox limit 9');
		$topdeals = \DB::select('select * from topdeals');
		$bestoffers = \DB::select('select * from offerbox');
		$coupons = \DB::select('select * from coupons limit 4');
		$usersRw = \DB::select('select * from usersReview');
		$adposter = \DB::select('select * from addposter');
    return view('index')->with('users', '$ads')->with('slider1', $slide1)->with('slider2', $slide2)->with('slider3', $slide3)->with('promobox', $promodata)
	->with('topdeals', $topdeals)->with('bestoffers', $bestoffers)->with('coupon', $coupons)->with('review', $usersRw)->with('ad', $adposter);
	  
   }
   
   
     public function moredeals()
   {
	$promodata = \DB::select('select * from promobox');
	
      return view('moredeals')->with('promobox', $promodata);
   }
   
    public function coupon()
   {
	$coupons = \DB::select('select * from coupons ');
	$adposter = \DB::select('select * from addposter');
      return view('coupons')->with('coupon', $coupons)->with('ad', $adposter);
   }
   
    public function flipkart()
   {
	
	$flipkart = \DB::select('select * from flipkartstore');
      return view('flipkart')->with('flipkartdata', $flipkart);
   }
   
    public function amazon()
   {
	
	$amazon = \DB::select('select * from amazonstore');
      return view('amazont')->with('amazondata', $amazon);
   }
   
   
    public function ajio()
   {
	
	$ajio = \DB::select('select * from ajiostore');
      return view('ajio')->with('ajiodata', $ajio);
   }
   
    public function myntra()
   {
	
	$myntra = \DB::select('select * from myntrastore');
      return view('myntra')->with('myntradata', $myntra);
   }
   
   
   
    public function bigrock()
   {
	
	$bigrock = \DB::select('select * from bigrockstore');
      return view('bigrock')->with('bigrockdata', $bigrock);
   }
   
    public function ebay()
   {
	
	$ebay = \DB::select('select * from ebaystore');
      return view('ebay')->with('ebaydata', $ebay);
   }
    public function paytm()   
   {
	
	$paytm = \DB::select('select * from paytmstore');
      return view('paytm')->with('paytmdata', $paytm);
   }
   
       public function mobikwik()   
   {
	
	$mobikwik = \DB::select('select * from mobikwikstore');
      return view('mobikwik')->with('mobikwikdata', $mobikwik);
   }
   
}
