<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Privacy Policy</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="keywords" content=" ">
     <link rel="icon" href="/static/images/logo.png">

    <!-- Bootstrap core CSS -->
    <link href="/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="/css/bootstrap-theme.min.css" rel="stylesheet">
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <link href="/css/ie10-viewport-bug-workaround.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="/mycss.css" rel="stylesheet">

    <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="/js/ie-emulation-modes-warning.js"></script>
		<style>
 body { 
   background-image:url(images/bgwap.jpg);
background-color:#f7f7f7;
   }
</style>
	
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
    </head>

    <body>

 
	
	
	<div class="top-header1 no-margin">

	<div class="row"><center>
  <div class="col-md-4">
   <img height="120px" width="160px" src="/images/logo.png"></img>

  </div>
  <div class="col-md-4"> </div>
  <div class="col-md-4"><br><br><font face="Georgia" size="4" color="white"><b>#Support@grabix.in</b></font></div>
  </center>
</div>
	
	
	
</div>

<nav class="navbar navbar-custom no-border" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><p style="font-family:cursive;font-size:18px"># Save with Us</p></a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                    <li>
                        <a href="index.php"><b>Home</b></a>
                    </li>
                    <li>
                        <a href="business.php"><b>Business</b></a>
                    </li>
                   
                   
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><b>Quick Links </b> <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li>
                                <a href="aboutus.php">About Us</a>
                            </li>
                            <li>
                                <a href="contactus.php">Contact Us</a>
                            </li>
                            <li>
                                <a href="team.php">Our Team</a>
                            </li>
                            <li>
                                <a href="work.php">Work With Us</a>
                            </li>
                            
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
	
	

      

      <div class="container" role="main">
	 
<br>
<center>
 <font face="Georgia" size="6" color="red"><b>Our Privacy</b></font>
<font face="Georgia" size="6" color="grey"><b>Policy</b></font>

    </center>


<div class="panel panel-default">
  <div class="panel-body">
  
   <center> <img src="/images/privacy2.jpg" class="img-responsive" alt="Privacy image"> </center>
   <br>
  
  
  <br>
    <p style="font-family:arial;font-size:16px"> Grabix is an online venture of Grabix Web Services  Operated and Managed by students of IIITs and  other Top institutes across country.
	We listed best offers,deals & coupons on our website of various online stores & services. 
	We provides you various choices for easy ,simplified and smart shopping.<br> We value our  users privacy so that we try our best to make our user personal information secure.
	Here "WE" and "Us" refer to Grabix.in</p>
	<br>
	<br>
	<h4><u>Personal Information </u></h4> <br>
	<br>
	<p style="font-family:arial;font-size:16px"> When user fill any form on our website we collect name ,mobile number,address etc for communcation purposes.<br>We collect so that
	we better understand you.
	
  
  
    </p>
	<br> <br>
	<h4><u>Information Sharing</u></h4> 
	<p style="font-family:arial;font-size:16px"> We do not share any of your personal information with others unless you may give us right to do so.<br>
	We may also need to share your data/information with other party that help us in our various business processes.<br>
	We may also be bound to share your information if we are forced to do so by the law, or government authority.<br><br>
	In any such situation like ownership transfer or sale of Grabix.in,you would be notified regarding this status to use your data.
	<br>
	</p>
	<br><br>
	<h4><u>Our Venture deatils</u></h4>
	<br>
	<p style="font-family:arial;font-size:16px"><strong>For any query regarding our policy and company contact us through support@grabix.in</strong></p>
	

	
  </div>
</div>







</div>
 <!-- /container -->

 
 
 
 
  
 <!--FOOTER START-->
 <footer class="myfooter">
 <div class="container">
 <center>
 <div class="row">
  <div class="col-md-4"><font face="verdana" size="4" color="grey"> <b><span class="glyphicon glyphicon-search" aria-hidden="true"></span> <u>About Grabix</u></b></font>
  <br> <br>
  <font face="verdana" size="2" color="grey"><center>
Grabix, India's fast growing Coupon & deal platform, helps you save money through posting  of coupons, offers and discounted deals on its portal. </center> </font>  </div>
  <div class="col-md-4"><font face="verdana" size="4" color="grey"><b> <span class="glyphicon glyphicon-duplicate" aria-hidden="true"></span> <u>Quick Links</u></b></font>
  <br>
  <br>    
  

  <p>  
   <a href="business.html"><font face="Verdana" size="2" color="grey"><b> Advertise with us</b></font>  </a> 
	<br>
	<a href="business.php"><font face="Verdana" size="2" color="grey"><b>Join Us</b></font> </a>
	<br>
    <a href=""><font face="Verdana" size="2" color="grey"><b>  Campus Ambassador </b></font>	</a> 
  <br>
  <a href="http://www.grabixworld.wordpress.com" > <font face="Verdana" size="2" color="grey"><b> Blog</b></font></a>
  </p>
  
  
  
  
  
  
  
  
  
  
  </div>
  <div class="col-md-4"><font face="verdana" size="4" color="grey"><b> <span class="glyphicon glyphicon-thumbs-up" aria-hidden="true"></span> <u>Connect</u></b></font>
  <br>
  <br>
   <p>  
   <a href="aboutus.php"><font face="Verdana" size="2" color="grey"><b> About Us</b></font>  </a> 
	<br>
	<a href="team.php"><font face="Verdana" size="2" color="grey"><b>Meet the Team</b></font> </a>
	<br>
    <a href="contactus.php"><font face="Verdana" size="2" color="grey"><b> Contact Us</b></font>	</a> 
  <br>
  <a href="work.php" > <font face="Verdana" size="2" color="grey"><b>Work with Us</b></font></a>
  </p>
  
  
  
  
  
  
  </div>
</div>
</center>
 <div class="bottom-footer">
 
 © Copyright: Grabix Web Services 2017
 <br>
 <a href="http://ourdisclaimer.com/?i=Grabix.in"><b>Disclaimer </b></a><a href="privacy.php"><b>| Privacy Policy</b></a>
 
 
 </div>
 </div>
 </footer>
 
 
 
 
 
 
 <!--FOOTER END-->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/docs.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="/js/ie10-viewport-bug-workaround.js"></script>
  </body>
</html>















 <!-- /container -->

   <!-- Bootstrap core JavaScript
    ================================================== -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
    <script src="/js/bootstrap.min.js"></script>
    <script src="/js/docs.min.js"></script>
	 <script src="/myjava.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="/js/ie10-viewport-bug-workaround.js"></script>
	
	
	
	
  </body>
</html>
