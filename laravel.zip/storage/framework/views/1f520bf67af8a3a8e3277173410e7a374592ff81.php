<html>
<head>
<title> adarsh </title>
</head>
<body>
welcome 
<table border = 1>
         <tr>
            <td>ID</td>
            <td>Name</td>
         </tr>
         <?php $__currentLoopData = $promobox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <tr>
            <td><?php echo e($user->ID); ?></td>
            <td><?php echo e($user->link); ?></td>
         </tr>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </table>


</body>




</html>