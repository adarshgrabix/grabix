<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('main');
});
*/
Auth::routes();

Route::get('/', 'maincontroller@index');

Route::get('/moredeals', 'maincontroller@moredeals');

Route::get('/coupons', 'maincontroller@coupon');

Route::get('/flipkart', 'maincontroller@flipkart');

Route::get('/amazon', 'maincontroller@amazon');

Route::get('/ajio', 'maincontroller@ajio');

Route::get('/myntra', 'maincontroller@myntra');

Route::get('/bigrock', 'maincontroller@bigrock');  

Route::get('/ebay', 'maincontroller@ebay');

Route::get('/paytm', 'maincontroller@paytm');

Route::get('/mobikwik', 'maincontroller@mobikwik');


Route::get('/business', function() {
 return view('business');	
	
});

Route::get('/aboutus', function() {
 return view('aboutus');	
	
});

Route::get('/privacy', function() {
 return view('privacy');	
	
});

Route::get('/team', function() {
 return view('ourteam');	
	
});

Route::get('/contact', function() {
 return view('contactus');	
	
});

Route::get('/work', function() {
 return view('work');	
	
});





